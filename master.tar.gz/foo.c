#include <stdio.h>
int foo(int i) {
 return i;   
}

int main()  {
int a=foo(3);
printf("function foo() a=%d",a);
printf("second line");
printf("third line");
printf("fourth line");
printf("fifth line");

printf();
printf();
printf();
printf("Master commit");
printf("Develop Branch");

printf("Develop Branch1");
printf("Develop commit");
printf("foo");
printf("try to merge");
printf("try to merge to master");
printf("Master Branch");

//no file
//no
//pppppp


}

